#!/bin/bash

set -e
killall cmdb_eventserver